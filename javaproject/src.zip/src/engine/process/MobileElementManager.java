package engine.process;

import java.util.ArrayList;
import config.DefaultGameSettings;
import config.GameConfiguration;

import engine.map.Block;
import engine.map.Map;
import engine.mobile.CPU;
import engine.mobile.MobileElement;
import engine.mobile.Player;
import engine.mobile.RessourceDeposit;
import engine.mobile.building.Building;
import engine.mobile.building.DefenseTower;
import engine.mobile.building.HQ;
import engine.mobile.building.UnitProducer;
import engine.mobile.unit.Unit;
import engine.mobile.unit.Worker;
import engine.process.chrono.Chronometer;
import engine.process.chrono.CyclicCounter;

/**
 * 
 * Manager pattern class. This is the main manager that manage the whole engine.
 * 
 * @author LE RAY Yann
 * @author ATCHAOUI Ilias
 * @author POSE Romain
 * @version 1.0
 *
 */
public class MobileElementManager implements MobileInterface {
	private DefaultGameSettings gameSettings;
    
	private Map map;
    
	
    private ArrayList<Building> buildings = new ArrayList<Building>();
    private ArrayList<Unit> unitsInSelectedArea = new ArrayList<Unit>();
    private ArrayList<Building> buildingsInSelectedArea = new ArrayList<Building>();
    private ArrayList<RessourceDeposit> ressourceDeposits = new ArrayList<RessourceDeposit>();
    
    private Building selectedBuild =null;
    private Worker selectedWorker =null;
    private int selectedTier =0;//for worker button
    private String typeSelection =null;
    private String notification =null;
    private boolean isNotificationGood=false;
    private boolean isGameStoped = false;
    
    private ArrayList<Unit> units = new ArrayList<Unit>();
    
    private ArrayList<Block> selectedArea;
    
    private Chronometer chronometer = new Chronometer();
    private CyclicCounter timetweaker = new CyclicCounter(0,68,0);

    private Player player;
    private CPU cpu;
    
    //this is for the two other manager, made separately for easier manipulation
    private BuildingInterface buildingManager;
    private UnitsInterface unitManager;
    private CPUManager cpuManager;
    
    public MobileElementManager(Map map, DefaultGameSettings gameSettings,String faction) {
        this.gameSettings=gameSettings;
    	this.map = map;
        this.player = new Player("Jhon Doe", faction);
        this.cpu = new CPU("Ian", "Hades",5,5,5);
        chronometer.init();
        this.buildingManager = new BuildingManager(this);
        this.unitManager = new UnitsManager(this,this.gameSettings);
        this.cpuManager=new CPUManager(this);
    }

    public void firstRound() {    	
    	initMap();
    }

	
    public void nextRound() {
        timetweaker.increment();
        processBySeconds();
        unitCombatSystem();
        
        unitManager.moveAllUnits(player);
        unitManager.moveAllUnits(cpu);
        
        buildingManager.allTowerAttack(buildings);
        
        cpuManager.attackReaction(cpu);
        cpuManager.workerManagement(cpu);
        cpuManager.buildManagement(cpu);
        cpuManager.otherBuildingsManagement(cpu);
        cpuManager.militaryProductionManagement(cpu);
        
        
    }

	

	private void processBySeconds() {
		/*
		 * Every slow process that don't need to be check every tick, for performance purpose
		 */
		//chronometer update
		nextTierCheck(player);
		if(timetweaker.getValue() == 66) {
            chronometer.increment();
            //Units manager
            for(Unit unit: new ArrayList<>(units)) {
            	//We copy Unit list because it can be manipulated elsewhere while we iterate it
            	if(unit.getHp()<=0) {
            		System.out.println("Unit '"+unit.getUnitName()+"' removed");
            		units.remove(unit);
      
            	}
                
            	// Ennemy scan
                if (unit.getTarget() == null && unit.getDestination() == null ) {
                    MobileElement target = unitManager.scanForEnemy(unit);
                    if (target != null) {
                    	unitManager.setCombatState(unit, target);
                    }
                }
            }
            
            for (int i = player.getCreatedUnits().size() - 1; i >= 0; i--) {
                if (player.getCreatedUnits().get(i).getHp()<=0) {
                	player.getCreatedUnits().remove(i);
                }
            }
            
            // Buildings management
            for(Building building : buildings) {
            	buildingManager.reduceConstructionTime(building);
            	if(building instanceof UnitProducer) {
            		UnitProducer producer = (UnitProducer) building;
            		buildingManager.removeQueue(producer);
            	}else if (building instanceof HQ) {
            		HQ hQ = (HQ) building;
            		buildingManager.removeQueue(hQ.getWorkerProducer());
            	}
            }
            for(Building tower: buildings) {
            	if(tower instanceof DefenseTower) {
            		buildingManager.setTowerTarget((DefenseTower) tower);
            	}
            }
            cpuManager.workerProductionManagement(cpu);
        }
	}
    
	private void nextTierCheck(Player player){
		/*
		 * Next tier is reach when every building of the lower tiers are built
		 */
		int nbOfBuiltBuildings=player.getBuiltBuilding().size();
		if(player.getCurrentTier()==1) {
			if(nbOfBuiltBuildings==2) { //there are 2 tiers 1 buildings for all factions, not counting HQ
				player.setCurrentTier(2);
			}
		}
		else if(player.getCurrentTier()==5) { //there are three tiers 2 buildings and two tiers 1 buildings for all factions
			player.setCurrentTier(3);
		}
		
		
	}
	private void unitCombatSystem() {
		for(int i=0;i<units.size();i++) {
        	Unit unit=units.get(i);
        	if (unit.getTarget() != null && unit.getIsInCombat()) {
        		MobileElement target = unit.getTarget();

        		if (target.getHp() <= 0) {
        			unit.setTarget(null);
        			unit.setIsInCombat(false);
        		} else {
        			double distance = getDistance(unit.getPosition(), target.getPosition());

        			if (distance <= unit.getATKRange()) {
        				unit.setDestination(null);
        				unitManager.damageCalculation(unit);
        			}else {
        				// if not in range, we pursue
        				unit.setDestination(target.getPosition());
        			}
        		}
        	}
        }
	}
    
    public double getDistance(Block b1, Block b2) {
        // Chebyshev distance to avoid issue with diagonal calculation
        int dx = Math.abs(b1.getColumn() - b2.getColumn());
        int dy = Math.abs(b1.getLine() - b2.getLine());
        return Math.max(dx, dy);
    }

    
    public void initSelectedArea(Block firstBlock) {
        this.selectedArea = new ArrayList<Block>();
        this.selectedArea.add(firstBlock);
    }
    
    public void calculateSelectedArea(Block lastBlock) {
        Block firstBlock = this.selectedArea.get(0);
        this.selectedArea= new ArrayList<Block>();//Reset the selected area
        
        int x1 = firstBlock.getLine();
        int y1 = firstBlock.getColumn();
        int x2 = lastBlock.getLine();
        int y2 = lastBlock.getColumn();
        
        if (x1 > x2) { int tmp = x1; x1 = x2; x2 = tmp; }
        if (y1 > y2) { int tmp = y1; y1 = y2; y2 = tmp; }

        for (int x = x1; x <= x2; x++) {
            for (int y = y1; y <= y2; y++) {
                this.selectedArea.add(map.getBlock(x, y));
            }
        }
        unitManager.unitsInSelectedArea();
        buildingManager.buildingsInSelectedArea();
    }
    

    
    public int isBlockCollider(Block block) {
        int nbOfUnits = this.units.size();
        int nbOfBats = this.buildings.size();
        for(int j = 0; j < nbOfBats; j++) {
            if(this.buildings.get(j).getPosition() == block){
                return 1;
            }
        }
        for(int i = 0; i < nbOfUnits; i++) {
            if(this.units.get(i).getPosition() == block){
                return 1;
            }
        }
        return 0;
    }
    
    //Gui call this to tell the manager that the player clicked in the selection button area
    //2 line 3 column
    //we indicate if its in the first or second line then for the col
    // do nothing if in the white space
    public void areaButtonPressed(int x, int y) {
    	/*
    	 * Create clickable area where button are drawn in bottom right part of the screen
    	 */
    	
    	if(selectedWorker!=null){
    		if(y<=620) {
    			if(x<=1080) {
    				unitManager.workerConstructionction("button1",player,selectedWorker);
    			} else if (x>=1100 && x<=1160) {
    				unitManager.workerConstructionction("button2",player,selectedWorker);
    			} else if (x>=1180) {
    				unitManager.workerConstructionction("button3",player,selectedWorker);
    			}
    		} else if (y>=640) {
    			if(x<=1080) {
    				unitManager.workerConstructionction("button4",player,selectedWorker);
    			} else if (x>=1100 && x<=1160) {
    				unitManager.workerConstructionction("button5",player,selectedWorker);
    			} else if (x>=1180) {
    				unitManager.workerConstructionction("button6",player,selectedWorker);
    			}
    		}
    	}else if(selectedBuild!=null) {
    		if(y<=620) {
    			if(x<=1080) {
    				buildingManager.action("button1",player);
    			} else if (x>=1100 && x<=1160) {
    				buildingManager.action("button2",player);
    			} else if (x>=1180) {
    				buildingManager.action("button3",player);
    			}
    		} else if (y>=640) {
    			if(x<=1080) {
    				buildingManager.action("button4",player);
    			} else if (x>=1100 && x<=1160) {
    				buildingManager.action("button5",player);
    			} else if (x>=1180) {
    				buildingManager.action("button6",player);
    			}
    		}
    	}
    }
    private void initMap() {
        // --- BASES DE DÉPART (HQs) ---
        // On définit les positions de départ pour le joueur et le CPU
        Block playerHQposition = map.getBlock(18, 18);
        Building playerHQ = BuildingFactory.createBuilding(BuildingFactory.HQ_BUILDING, 1, "Zeus", playerHQposition);
        playerHQ.setUnderConstruction(false);
        player.getBuiltBuilding().add(playerHQ);
        
        Block ennemyHQposition = map.getBlock(60, 82);
        Building ennemyHQ = BuildingFactory.createBuilding(BuildingFactory.HQ_BUILDING, 1, DefaultGameSettings.HADES, ennemyHQposition);
        ennemyHQ.setUnderConstruction(false);
        cpu.getBuiltBuilding().add(ennemyHQ);

        ArrayList<RessourceDeposit> allDeposits = new ArrayList<>();

        // ═════ 1. MAIN BASES (En U très large autour des QG) ═════
        // Joueur
        allDeposits.add(new RessourceDeposit(map.getBlock(12, 18), RessourceDeposit.AMBROSIA));
        allDeposits.add(new RessourceDeposit(map.getBlock(14, 13), RessourceDeposit.FAITH));
        allDeposits.add(new RessourceDeposit(map.getBlock(18, 12), RessourceDeposit.AMBROSIA));
        allDeposits.add(new RessourceDeposit(map.getBlock(22, 13), RessourceDeposit.FAITH));
        allDeposits.add(new RessourceDeposit(map.getBlock(24, 18), RessourceDeposit.AMBROSIA));

        // CPU
        allDeposits.add(new RessourceDeposit(map.getBlock(66, 82), RessourceDeposit.AMBROSIA));
        allDeposits.add(new RessourceDeposit(map.getBlock(64, 87), RessourceDeposit.FAITH));
        allDeposits.add(new RessourceDeposit(map.getBlock(60, 88), RessourceDeposit.AMBROSIA));
        allDeposits.add(new RessourceDeposit(map.getBlock(56, 87), RessourceDeposit.FAITH));
        allDeposits.add(new RessourceDeposit(map.getBlock(54, 82), RessourceDeposit.AMBROSIA));

        // ═════ 2. NATURAL EXPANSIONS / B2 (Clusters carrés très aérés) ═════
        // Joueur B2 (Centre-gauche)
        allDeposits.add(new RessourceDeposit(map.getBlock(31, 23), RessourceDeposit.AMBROSIA));
        allDeposits.add(new RessourceDeposit(map.getBlock(33, 28), RessourceDeposit.FAITH));
        allDeposits.add(new RessourceDeposit(map.getBlock(37, 28), RessourceDeposit.AMBROSIA));
        allDeposits.add(new RessourceDeposit(map.getBlock(39, 23), RessourceDeposit.FAITH));

        // CPU B2 (Centre-droite)
        allDeposits.add(new RessourceDeposit(map.getBlock(35, 77), RessourceDeposit.AMBROSIA));
        allDeposits.add(new RessourceDeposit(map.getBlock(37, 72), RessourceDeposit.FAITH));
        allDeposits.add(new RessourceDeposit(map.getBlock(40, 72), RessourceDeposit.AMBROSIA));
        allDeposits.add(new RessourceDeposit(map.getBlock(44, 77), RessourceDeposit.FAITH));

        // ═════ 3. BASES LATÉRALES / B3 (Sur les flancs haut et bas) ═════
        // Joueur B3 (Bottom-Left)
        allDeposits.add(new RessourceDeposit(map.getBlock(48, 18), RessourceDeposit.AMBROSIA));
        allDeposits.add(new RessourceDeposit(map.getBlock(49, 23), RessourceDeposit.FAITH));
        allDeposits.add(new RessourceDeposit(map.getBlock(52, 23), RessourceDeposit.AMBROSIA));
        allDeposits.add(new RessourceDeposit(map.getBlock(51, 18), RessourceDeposit.FAITH));

        // CPU B3 (Top-Right)
        allDeposits.add(new RessourceDeposit(map.getBlock(18, 82), RessourceDeposit.AMBROSIA));
        allDeposits.add(new RessourceDeposit(map.getBlock(20, 77), RessourceDeposit.FAITH));
        allDeposits.add(new RessourceDeposit(map.getBlock(24, 77), RessourceDeposit.AMBROSIA));
        allDeposits.add(new RessourceDeposit(map.getBlock(22, 82), RessourceDeposit.FAITH));

        // ═════ 4. ZONES CONTESTÉES (Le long de la diagonale centrale) ═════
        allDeposits.add(new RessourceDeposit(map.getBlock(17, 48), RessourceDeposit.AMBROSIA));
        allDeposits.add(new RessourceDeposit(map.getBlock(18, 52), RessourceDeposit.FAITH));
        allDeposits.add(new RessourceDeposit(map.getBlock(22, 52), RessourceDeposit.AMBROSIA));
        allDeposits.add(new RessourceDeposit(map.getBlock(23, 48), RessourceDeposit.FAITH));

        allDeposits.add(new RessourceDeposit(map.getBlock(52, 48), RessourceDeposit.FAITH));
        allDeposits.add(new RessourceDeposit(map.getBlock(53, 52), RessourceDeposit.AMBROSIA));
        allDeposits.add(new RessourceDeposit(map.getBlock(57, 52), RessourceDeposit.FAITH));
        allDeposits.add(new RessourceDeposit(map.getBlock(58, 48), RessourceDeposit.AMBROSIA));

        // Initialisation globale des gisements
        for (RessourceDeposit d : allDeposits) {
            d.setMaxWorkers(2); 
            d.setCurrentWorkers(0);
            this.ressourceDeposits.add(d);
        }

        // --- UNITÉS DE DÉPART ---
        // Armée de départ du joueur
        for(int i=0; i<7; i++) {
            Block spawnBlock = map.getBlock(22+(int)(Math.random()*3), 22+(int)(Math.random()*3));
            Unit unit = UnitFactory.createUnit(UnitFactory.ARTILLERY_UNIT, 1, DefaultGameSettings.ZEUS, spawnBlock);
            this.units.add(unit);
            player.getCreatedUnits().add(unit);
        }

        // Armée de départ du CPU
        for(int i=0; i<5; i++) {
            Block spawnBlock = map.getBlock(54+(int)(Math.random()*3), 75+(int)(Math.random()*3));
            Unit unit = UnitFactory.createUnit(UnitFactory.INFANTRY_UNIT, 1, DefaultGameSettings.HADES, spawnBlock);
            this.units.add(unit);
            cpu.getCreatedUnits().add(unit);
        }
        
        // Workers de départ du CPU (indispensable pour l'IA)
        Unit w1 = UnitFactory.createUnit(UnitFactory.WORKER_UNIT, 1, DefaultGameSettings.HADES, ennemyHQ.getPosition());
        Unit w2 = UnitFactory.createUnit(UnitFactory.WORKER_UNIT, 1, DefaultGameSettings.HADES, ennemyHQ.getPosition());
        ((Worker) w1).setCurrentHQ((HQ) ennemyHQ);
        ((Worker) w2).setCurrentHQ((HQ) ennemyHQ);
        this.units.add(w1); cpu.getCreatedUnits().add(w1);
        this.units.add(w2); cpu.getCreatedUnits().add(w2);

        // Ajout final des bâtiments aux listes globales
        this.buildings.add(playerHQ);
        this.buildings.add(ennemyHQ);
        System.out.println("Vision HQ: " + playerHQ.getVision());
    }
    
    public void motherload() {
    	/**
    	 * Set infinite ressources for the player
    	 */
    	player.setAmbroisieStock(999999);
    	player.setFaithStock(999999);
    	player.setMaxPopulation(999999);
    	setNotifText("Motherload activated", true);
    }
    public void cpuLoad() {
    	/**
    	 * Set infinite ressources for the player
    	 */
    	cpu.setAmbroisieStock(999999);
    	cpu.setFaithStock(999999);
    	setNotifText("cpuLoad activated", true);
    }
    
    public boolean ifBlockInGamePanel(Block block) {
    	if(block.getColumn()<=100 && block.getLine()>=7) {
    		return true;
    	}else {
    		return false;
    	}
    }
    //method for the communation between this class and BuildingManager
    
    public void addInBuildings(Building n) {
        synchronized(this.buildings) {
            this.buildings.add(n);
        }
    }

    public void addInUnits(Unit u) {
        synchronized(this.units) {
            this.units.add(u);
        }
    }
    public Map getMap() {
    	return this.map;
    }
    public ArrayList<Building> getBuildings() {
        return buildings;
    }
    
    public ArrayList<RessourceDeposit> getRessourceDeposit(){
    	return this.ressourceDeposits;
    }

    public ArrayList<Unit> getUnits() {
        return units;
    }

    public ArrayList<Unit> getUnitsInSelectedArea(){
        return unitsInSelectedArea;
    }
    public void setUnitsInSelectedArea(ArrayList<Unit> units){
        this.unitsInSelectedArea=units;
    }
    
    public ArrayList<Building> getBuildingsInSelectedArea(){
    	return buildingsInSelectedArea;
    }
    
    @Override
    public void selectUnit(String type) {
        unitManager.selectUnit(type);
    }

    @Override
    public void selectBuilding(String type) {
        buildingManager.selectBuilding(type);
    }

    @Override
    public void spawnUnit(Block position, String faction) {
        unitManager.spawnUnit(position, faction);
    }
    
    @Override
    public int buildBuilding(Block position, int tier, String faction, Player p) {
        int result = buildingManager.buildBuilding(position, tier, faction, p); // p et non player
        boolean playerBuild = faction.equals(gameSettings.getPlayerFaction());
        if (playerBuild) {
            if (result == 1) {
                setNotifText("Batiment ajouté", true);
            } else {
                setNotifText("Ressources insuffisantes", false);
            }
        }
        return result;
    }

    @Override
    public void unitMoveOrder(Block destination) {
        unitManager.unitMoveOrder(destination,map);
    }

    @Override
    public void addQueue(UnitProducer building, Block position, String unitType, Player p) {
        if(p.getCurrentPopulation()<p.getMaxPopulation()&&building.getProductionQueue().size()<3) {
    		buildingManager.addQueue(building, position, unitType,p);
    		p.setCurrentPopulation(p.getCurrentPopulation()+1);
        }
       
    }
    
    // --- Timer part ---
    public CyclicCounter getHour() {
        return chronometer.getHour();
    }
        
    public CyclicCounter getMinute() {
        return chronometer.getMinute();
    }
    
    public CyclicCounter getSecond() {
        return chronometer.getSecond();
    }
    
    //other method
    public Block getMousePosition(int x, int y) {
        int line = x / GameConfiguration.BLOCK_SIZE;
        int column = y / GameConfiguration.BLOCK_SIZE;
        if(column>map.getColumnCount())
        	column=map.getColumnCount()-1;
        if(column<0)
        	column=0;
        if(line>map.getLineCount())
        	line=map.getLineCount()-1;
        if(line<0)
        	line=0;
        return map.getBlock(line, column);
    }
    
    public ArrayList<Block> getSelectedArea() {
        return selectedArea;
    }
    public void setSelectedArea(ArrayList<Block> selectedArea) {
        this.selectedArea=selectedArea;
    }
    
    public Player getPlayer() {
        return this.player;
    }
    
    //used for graphic interface
    public ArrayList<Unit> getUnitInSelectedArea(){
    	return this.unitsInSelectedArea;
    }
	public Building getSelectedBuild() {
		return selectedBuild;
	}

	public void setSelectedBuild(Building selectedBuild) {
		this.selectedBuild = selectedBuild;
	}
	
	public Worker getSelectedWorker() {
		return selectedWorker;
	}

	public void setSelectedWorker(Worker selectedWorker) {
		this.selectedWorker=selectedWorker;
	}

	public int getSelectedTier() {
		return selectedTier;
	}

	public void setSelectedTier(int selectedTier) {
		this.selectedTier = selectedTier;
	}

	public String getTypeSelection() {
		return typeSelection;
	}

	public void setTypeSelection(String typeSelection) {
		this.typeSelection = typeSelection;
	}
	
	public void addUnitsInSelectedArea(Unit unit) {
		this.unitsInSelectedArea.add(unit);
	}

	public CPU getCpu() {
		return cpu;
	}

	public void setCpu(CPU cpu) {
		this.cpu = cpu;
	}

	public CPUManager getCpuManager() {
		return cpuManager;
	}

	public void setCpuManager(CPUManager cpuManager) {
		this.cpuManager = cpuManager;
	}
	
	public void setNotifText(String info,boolean isgood) {
		if (info!=null) {
			this.notification =info;
			this.isNotificationGood=isgood;
		} else {
			this.notification=null;
			this.isNotificationGood=false;
		}
	}
	
	public String getNotification() {
		return this.notification;
	}
	
	public boolean isNotificationGood() {
		return this.isNotificationGood;
	}

	public boolean isGameStoped() {
		return isGameStoped;
	}

	public void setIsGameStoped(boolean stop) {
		this.isGameStoped = stop;
	}
}